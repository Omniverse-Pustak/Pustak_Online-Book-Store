﻿using System;
using System.Collections.Generic;

namespace Pustak.Models
{
    public class Wishlist
    {
        public Guid WishlistId { get; set; }
        public int UserID { get; set; }
        public DateTime DateCreated { get; set; }
        public List<WishlistItem>? Items { get; set; }
    }
}
