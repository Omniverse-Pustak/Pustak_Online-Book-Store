﻿namespace Pustak.Models
{
    public class UserType
    {
        public int UserTypeID { get; set; }
        public string UserTypeName { get; set; } = null!;
    }
}
