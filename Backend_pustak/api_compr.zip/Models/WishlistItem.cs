﻿namespace Pustak.Models
{
    public class WishlistItem
    {
        public int WishlistItemId { get; set; }
        public Guid WishlistId { get; set; }
        public Wishlist Wishlist { get; set; } = null!;
        public int ProductId { get; set; }
    }
}
