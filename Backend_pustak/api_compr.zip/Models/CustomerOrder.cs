﻿using System;
using System.Collections.Generic;

namespace Pustak.Models
{
    public class CustomerOrder
    {
        public string OrderId { get; set; } = null!;
        public int UserID { get; set; }
        public DateTime DateCreated { get; set; }
        public decimal CartTotal { get; set; }
        public List<CustomerOrderDetail>? Details { get; set; }
    }
}
