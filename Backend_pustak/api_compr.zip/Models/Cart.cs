﻿using System;
using System.Collections.Generic;

namespace Pustak.Models
{
    public class Cart
    {
        public Guid CartId { get; set; }
        public int UserID { get; set; }
        public DateTime DateCreated { get; set; }
        public List<CartItem>? Items { get; set; }
    }
}
