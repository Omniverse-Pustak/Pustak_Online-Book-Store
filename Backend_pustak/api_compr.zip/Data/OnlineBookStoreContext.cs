﻿using Microsoft.EntityFrameworkCore;
using Pustak.Models;

namespace Pustak.Data
{
    public class OnlineBookStoreContext : DbContext
    {
        public OnlineBookStoreContext(DbContextOptions<OnlineBookStoreContext> options)
          : base(options) { }

        public DbSet<Category> Categories { get; set; }
        public DbSet<UserType> UserTypes { get; set; }
        public DbSet<UserMaster> Users { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<CustomerOrder> Orders { get; set; }
        public DbSet<CustomerOrderDetail> OrderDetails { get; set; }
        public DbSet<Wishlist> Wishlists { get; set; }
        public DbSet<WishlistItem> WishlistItems { get; set; }

        protected override void OnModelCreating(ModelBuilder mb)
        {
            // --- UserMaster (you already have) ---
            mb.Entity<UserMaster>(eb =>
            {
                eb.ToTable("UserMaster");
                eb.HasKey(u => u.UserID);
                eb.Property(u => u.PasswordHash)
                  .HasColumnName("Password")
                  .HasColumnType("varchar(100)")
                  .IsRequired();
            });

            // --- UserType ---
            mb.Entity<UserType>(eb =>
            {
                eb.ToTable("UserType");
                eb.HasKey(t => t.UserTypeID);
            });

            // --- Category ---
            mb.Entity<Category>(eb =>
            {
                eb.ToTable("Categories");
                eb.HasKey(c => c.CategoryID);
            });

            // --- Book ---
            mb.Entity<Book>(eb =>
            {
                eb.ToTable("Book");
                eb.HasKey(b => b.BookID);
                eb.Property(b => b.Price).HasPrecision(10, 2);
            });

            // --- Cart ---
            mb.Entity<Cart>(eb =>
            {
                eb.ToTable("Cart");
                eb.HasKey(c => c.CartId);
            });

            // --- CartItem ---
            mb.Entity<CartItem>(eb =>
            {
                eb.ToTable("CartItems");
                eb.HasKey(ci => ci.CartItemId);
            });

            // --- CustomerOrder ---
            mb.Entity<CustomerOrder>(eb =>
            {
                eb.ToTable("CustomerOrders");
                eb.HasKey(o => o.OrderId);                  // ← KEY MAPPING
                eb.Property(o => o.CartTotal).HasPrecision(10, 2);
            });

            // --- CustomerOrderDetail ---
            mb.Entity<CustomerOrderDetail>(eb =>
            {
                eb.ToTable("CustomerOrderDetails");
                eb.HasKey(d => d.OrderDetailsId);           // ← KEY MAPPING
                eb.Property(d => d.Price).HasPrecision(10, 2);
            });

            // --- Wishlist ---
            mb.Entity<Wishlist>(eb =>
            {
                eb.ToTable("Wishlist");
                eb.HasKey(w => w.WishlistId);
            });

            // --- WishlistItem ---
            mb.Entity<WishlistItem>(eb =>
            {
                eb.ToTable("WishlistItems");
                eb.HasKey(wi => wi.WishlistItemId);
            });
        }





    }
}
