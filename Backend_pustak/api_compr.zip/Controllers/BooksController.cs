﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pustak.Data;
using Pustak.Models;

namespace Pustak.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BooksController : ControllerBase
    {
        private readonly OnlineBookStoreContext _ctx;
        public BooksController(OnlineBookStoreContext ctx) => _ctx = ctx;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Book>>> GetAll() =>
            await _ctx.Books.ToListAsync();

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> Create(Book book)
        {
            _ctx.Books.Add(book);
            await _ctx.SaveChangesAsync();
            return CreatedAtAction(nameof(GetAll), new { id = book.BookID }, book);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Book updated)
        {
            var book = await _ctx.Books.FindAsync(id);
            if (book == null) return NotFound();

            book.Title = updated.Title;
            book.Author = updated.Author;
            book.Category = updated.Category;
            book.Price = updated.Price;
            book.CoverFileName = updated.CoverFileName;
            await _ctx.SaveChangesAsync();

            return NoContent();
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var book = await _ctx.Books.FindAsync(id);
            if (book == null) return NotFound();

            _ctx.Books.Remove(book);
            await _ctx.SaveChangesAsync();
            return NoContent();
        }
    }
}
