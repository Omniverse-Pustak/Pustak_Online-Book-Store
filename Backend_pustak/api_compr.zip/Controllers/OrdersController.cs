﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pustak.Data;
using Pustak.Dtos;
using Pustak.Models;

namespace Pustak.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class OrdersController : ControllerBase
    {
        private readonly OnlineBookStoreContext _ctx;
        public OrdersController(OnlineBookStoreContext ctx) => _ctx = ctx;

        [HttpPost("place")]
        public async Task<IActionResult> PlaceOrder(PlaceOrderDto dto)
        {
            var cart = await _ctx.Carts
                .Include(c => c.Items)
                .FirstOrDefaultAsync(c => c.UserID == dto.UserId);

            if (cart == null || !cart.Items!.Any())
                return BadRequest("Cart is empty");

            decimal total = 0;
            foreach (var ci in cart.Items)
            {
                var book = await _ctx.Books.FindAsync(ci.ProductId);
                total += (book?.Price ?? 0) * ci.Quantity;
            }

            var order = new CustomerOrder
            {
                OrderId = Guid.NewGuid().ToString(),
                UserID = dto.UserId,
                DateCreated = DateTime.UtcNow,
                CartTotal = total
            };
            _ctx.Orders.Add(order);
            await _ctx.SaveChangesAsync();

            foreach (var ci in cart.Items)
            {
                _ctx.OrderDetails.Add(new CustomerOrderDetail
                {
                    OrderId = order.OrderId,
                    ProductId = ci.ProductId,
                    Quantity = ci.Quantity,
                    Price = (await _ctx.Books.FindAsync(ci.ProductId))!.Price
                });
            }

            _ctx.CartItems.RemoveRange(cart.Items);
            await _ctx.SaveChangesAsync();

            return Ok(new { order.OrderId });
        }

        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<CustomerOrder>>> GetHistory(int userId)
        {
            var history = await _ctx.Orders
                .Include(o => o.Details)
                .Where(o => o.UserID == userId)
                .ToListAsync();

            return history;
        }
    }
}
