﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pustak.Data;
using Pustak.Dtos;
using Pustak.Models;

namespace Pustak.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CartController : ControllerBase
    {
        private readonly OnlineBookStoreContext _ctx;
        public CartController(OnlineBookStoreContext ctx) => _ctx = ctx;

        [HttpGet("{userId}")]
        public async Task<ActionResult<Cart>> GetCart(int userId)
        {
            var cart = await _ctx.Carts
                .Include(c => c.Items)
                .FirstOrDefaultAsync(c => c.UserID == userId);
            return cart == null ? NotFound() : cart;
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddToCart(AddCartItemDto dto)
        {
            var cart = await _ctx.Carts
                .Include(c => c.Items)
                .FirstOrDefaultAsync(c => c.CartId == dto.CartId);

            if (cart == null)
            {
                cart = new Cart
                {
                    CartId = dto.CartId,
                    UserID = dto.UserId,
                    DateCreated = DateTime.UtcNow,
                    Items = new()
                };
                _ctx.Carts.Add(cart);
            }

            var item = cart.Items!.FirstOrDefault(i => i.ProductId == dto.ProductId);
            if (item != null)
                item.Quantity += dto.Quantity;
            else
                cart.Items.Add(new CartItem
                {
                    ProductId = dto.ProductId,
                    Quantity = dto.Quantity
                });

            await _ctx.SaveChangesAsync();
            return Ok();
        }

        [HttpDelete("remove/{cartItemId}")]
        public async Task<IActionResult> RemoveItem(int cartItemId)
        {
            var item = await _ctx.CartItems.FindAsync(cartItemId);
            if (item == null) return NotFound();

            _ctx.CartItems.Remove(item);
            await _ctx.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("clear/{userId}")]
        public async Task<IActionResult> Clear(int userId)
        {
            var cart = await _ctx.Carts
                .Include(c => c.Items)
                .FirstOrDefaultAsync(c => c.UserID == userId);

            if (cart != null)
            {
                _ctx.CartItems.RemoveRange(cart.Items!);
                await _ctx.SaveChangesAsync();
            }
            return NoContent();
        }
    }
}
