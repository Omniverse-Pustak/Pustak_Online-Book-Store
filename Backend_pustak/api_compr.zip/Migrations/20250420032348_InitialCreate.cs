﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pustak.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Intentionally left blank – existing database schema is our baseline.
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Intentionally left blank – do not drop existing tables.
        }
    }
}
