﻿namespace Pustak.Dtos
{
    public class PlaceOrderDto
    {
        public int UserId { get; set; }
    }
}
